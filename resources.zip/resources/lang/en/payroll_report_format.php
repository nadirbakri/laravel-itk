<?php

return [
    'judul' => 'Report Format',
    'list' => 'Report Format',
    'list_detail' => 'Report Format List',
    'label_next' => 'Next',
    'label_back' => 'Back',
    'label_list' => 'List',
    'label_new' => 'New',
    'label_edit' => 'Edit',
    'label_activate' => 'Activate',
    'label_deactivate' => 'Deactivate',
    'label_report_code' => 'Report Code',
    'label_description' => 'Description',
    'label_font_size' => 'Font Size',
    'label_record_status' => 'Record Status',
    'label_column_no' => 'Column No',
    'label_table_name' => 'Table Name',
    'label_field_name' => 'Field Name',
    'label_column_header' => 'Column Header',
    'label_alignment' => 'Alignment',
    'label_data_format' => 'Data Format',
    'label_display' => 'Display',
    'label_select_table_name' => 'Choose Table Name',
    'label_select_alignment' => 'Choose Alignment',
    'label_select_data_format' => 'Choose Data Format',
    'label_select_criteria' => 'Choose Criteria',
    'label_condition' => 'Condition',
    'label_seq_no' => 'Seq No',
    'label_criteria' => 'Criteria',
    'label_value' => 'Value',
    'seq_no_required' => 'Seq No Required',
    'btn_save' => 'Save',
    'btn_add' => 'Add',
    'btn_cancel' => 'Cancel',
    'btn_remove'=> 'Remove',
    'alert_success' => 'Success !',
    'field_mandatory' => "This field can't be blank"

]

?>