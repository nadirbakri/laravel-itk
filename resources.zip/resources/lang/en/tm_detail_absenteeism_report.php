<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Time Management - Monthly Absenteeism Analysis Page Language Lines
    |--------------------------------------------------------------------------
    |
    | Pengaturan Halaman Time Management - Monthly Absenteeism Analysis Menggunakan Locale Bahasa Inggris. Akses di file
    | tm_report_monthly_absenteeism_analysis.blade.php
    |
    */

    'judul' => 'Absenteeism Report Detail',
    'list' => 'Time Management Menu List',
    'label_employee_no_from' => 'Employee No From',
    'label_employee_no_to' => 'Employee No To',
    'label_absent_date_from' => 'Absent Date From',
    'label_absent_date_to' => 'Absent Date To',
    'label_group_authorize_from' => 'Group Authorize From',
    'label_group_authorize_to' => 'Group Authorize To',
    'label_absent_code' => 'Absent Code :',
    'label_absent_code_all' => 'All',
    'label_absent_code_selection' => 'Selection',
    'label_table_absent_code' => 'Absent Code',
    'label_table_description' => 'Description',
    'label_table_leave' => 'Leave',
    'label_table_selection' => '*selected item',
    'label_include_resign' => 'Include Resign',
    'label_position' => 'Position',
    'label_ranking' => 'Ranking',
    'label_location' => 'Location',
    'btn_print' => 'Print'

];
