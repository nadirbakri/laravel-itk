<?php

return [
    'judul' => 'Laporan Berkala',
    'list' => 'Laporan Berkala',
    'label_grand_total' => 'Total Akhir',
    'label_report_name' => 'Nama Laporan',
    'label_employee_no' => 'No Karyawan',
    'label_to' => 'Ke',
    'label_period' => 'Periode',
    'label_cost_center' => 'Pusat Biaya',
    'label_multi_cost_center' => 'Pusat Multi Biaya',
    'label_report_status' => 'Status Laporan',
    'label_actual' => 'Aktual',
    'label_reconsiliation' => 'Rekonsiliasi',
    'label_report_type' => 'Tipe Laporan',
    'label_detail' => 'Detail',
    'label_summary' => 'Ringkasan',
    'label_group_authorized_code' => 'Kode Grup Otorisasi',
    'label_display_line' => 'Tampilkan Garis',
    'label_print_signature' => 'Cetak Tanda Tangan',
    'label_position' => 'Posisi',
    'label_ranking' => 'Ranking',
    'label_location' => 'Lokasi',
    'btn_preview' => 'Pratinjau',
    'btn_send_to' => 'Kirim Ke',
    'alert_success' => 'Sukses !'

]

?>