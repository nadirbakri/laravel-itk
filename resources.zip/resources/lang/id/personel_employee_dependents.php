<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Personel - Employee List Page Language Lines
    |--------------------------------------------------------------------------
    |
    | Pengaturan Halaman Personel - Employee List Menggunakan Locale Bahasa Indonesia. Akses di file
    | personel_employee_dependents.blade.php
    |
    */

    'judul' => 'Halaman Tanggungan Karyawan',
    'list' => 'Daftar Menu Personel',
    'label_employee_no_from' => 'Dari No Karyawan',
    'label_employee_no_to' => 'Sampai No Karyawan',
    'label_period' => 'Periode',
    'label_include_resign' => 'Termasuk Karyawan Mengundurkan Diri',
    'label_include_medical' => 'Termasuk Medis',
    'label_include_payroll' => 'Termasuk Gaji',
    'label_group_authorize_from' => 'Dari Grup Otorisasi',
    'label_group_authorize_to' => 'Sampai Grup Otorisasi',
    'label_position' => 'Jabatan',
    'label_ranking' => 'Peringkat',
    'label_location' => 'Lokasi',
    'btn_print' => 'Cetak'
]

?>