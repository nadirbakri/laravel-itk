<?php

return [
    'judul' => 'Proses Perhitungan Absen & Lembur',
    'list' => 'Proses Perhitungan Absen & Lembur',
    'label_process_period' => 'Periode Proses',
    'label_process_period_month' => 'Bulan',
    'label_process_period_year' => 'Tahun',
    'label_range_employee_no' => 'Jangkauan',
    'label_employee_no_from' => 'No Karyawan Dari',
    'label_employee_no_to' => 'No Karyawan Sampai',
    'btn_process' => 'Process',
    'btn_cancel' => 'Cancel',
    'alert_success' => 'Sukses !'
]

?>