<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Personel - Employee List Page Language Lines
    |--------------------------------------------------------------------------
    |
    | Pengaturan Halaman Personel - Employee List Menggunakan Locale Bahasa Inggris. Akses di file
    | personel_employee_list.blade.php
    |
    */

    'judul' => 'Pergantian Karyawan',
    'list' => 'Daftar Menu Personel',
    'label_employee_no_from' => 'Dari No Karyawan',
    'label_employee_no_to' => 'Sampai No Karyawan',
    'label_period_from' => 'Dari Periode',
    'label_period_to' => 'Sampai Periode',
    'label_group_authorize_from' => 'Dari Grup Otorisasi',
    'label_group_authorize_to' => 'Sampai Grup Otorisasi',
    'label_position' => 'Jabatan',
    'label_ranking' => 'Peringkat',
    'label_location' => 'Lokasi',
    'btn_print' => 'Cetak'

];
