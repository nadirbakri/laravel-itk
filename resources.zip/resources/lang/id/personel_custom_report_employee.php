<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Personel - Employee List Page Language Lines
    |--------------------------------------------------------------------------
    |
    | Pengaturan Halaman Personel - Employee List Menggunakan Locale Bahasa Inggris. Akses di file
    | personel_custom_report_employee.blade.php
    |
    */

    'judul' => 'Halaman Kartu Karyawan',
    'list' => 'Daftar Menu Personel',
    'label_employee_no_from' => 'Dari No Karyawan',
    'label_employee_no_to' => 'Sampai No Karyawan',
    'label_employment_status' => 'Status Karyawan',
    'label_include_resign' => 'Termasuk Karyawan Mengundurkan Diri',
    'label_group_authorize_from' => 'Dari Grup Otorisasi',
    'label_group_authorize_to' => 'Sampai Grup Otorisasi',
    'btn_add' => 'Tambah',
    'btn_remove' => 'Hapus',
    'btn_print' => 'Cetak',
    'btn_save' => 'Simpan',
    'btn_cancel' => 'Batal',
    'field_name_required' => 'Field Name Harus Diisi',
    'column_header_required' => 'Column Header Harus Diisi'
];